process.stdout.write = jest.fn()
